import 'dart:async';

import 'package:btt/View/Utilites/Colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:synchronized/synchronized.dart';

import '../../controller/homecontroller.dart';
import '../Widget/widget.dart';

class autobidpage extends StatefulWidget {
  const autobidpage({super.key});

  @override
  State<autobidpage> createState() => _autobidpageState();
}

class _autobidpageState extends State<autobidpage> {
  String TotalRate = "";
  String Nextpossible = "";
  int itemnameindex = -1;
  int qunindex = -1;
  int yourrankindex = -1;
  int nextpossindex = -1;
  int lastbidindex = -1;
  int startindex = -1;
  int incrementindex = -1;
  int h1bidindex = -1;
  int totalrateindex = -1;
  final List<TextEditingController> _controllers = [];
  int items = 0;
  String indexf() {
    final get = Get.put(homeController(context: context));
    //final detail = get.Response11.value.responseData!.biddingHallDetail![0];
    //final cellValueList = detail.auctionCellValueList!;
    itemnameindex = get.Response11.value.responseData!.auctionColumnHeader!
        .indexWhere((element) => element.columntypeid == 1);
    qunindex = get.Response11.value.responseData!.auctionColumnHeader!
        .indexWhere((element) => element.columntypeid == 2);
    yourrankindex = get.Response11.value.responseData!.auctionColumnHeader!
        .indexWhere((element) => element.columntypeid == 10005);
    nextpossindex = get.Response11.value.responseData!.auctionColumnHeader!
        .indexWhere((element) => element.columntypeid == 10003);
    lastbidindex = get.Response11.value.responseData!.auctionColumnHeader!
        .indexWhere((element) => element.columntypeid == 10004);
    startindex = get.Response11.value.responseData!.auctionColumnHeader!
        .indexWhere((element) => element.columntypeid == 10001);
    incrementindex = get.Response11.value.responseData!.auctionColumnHeader!
        .indexWhere((element) => element.columntypeid == 10007);
    h1bidindex = get.Response11.value.responseData!.auctionColumnHeader!
        .indexWhere((element) => element.columntypeid == 10002);
    totalrateindex = get.Response11.value.responseData!.auctionColumnHeader!
        .indexWhere((element) => element.columntypeid == 5);
    return "null";
  }

  String Remaining(String enddate) {
    String endDateStr = enddate;
    DateTime endDate = DateFormat("dd/MM/yyyy HH:mm:ss").parse(endDateStr);

    // Get the current date (without time)
    DateTime currentDate = DateTime.now();
    currentDate =
        DateTime(currentDate.year, currentDate.month, currentDate.day);

    // Calculate the difference in days
    Duration difference = endDate.difference(currentDate);
    int remainingDays = difference.inDays;
    return remainingDays.toString();
  }

  @override
  void initState() {
    final get = Get.put(homeController(context: context));
    for (int i = 0;
        i <
            num.parse(get
                    .Response11.value.responseData?.biddingHallDetail!.length
                    .toString() ??
                "0");
        i++) {
      _controllers.add(TextEditingController());
      items++;
    }
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final heights = MediaQuery.of(context).size.height;
    final widths = MediaQuery.of(context).size.width;
    final get = Get.put(homeController(context: context));

    return Scaffold(
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: [
              sbh(50.0),
              SizedBox(
                width: widths * 0.95,
                height: 50,
                child: Row(
                  children: [
                    const SizedBox(
                      width: 10,
                    ),
                    IconButton(
                      onPressed: () {
                        get.autobiddingstates = false;
                        Get.toNamed("/itemselection");
                      },
                      icon: Icon(
                        Icons.arrow_back_ios_sharp,
                      ),
                    ),
                    SizedBox(
                      width: widths * 0.55,
                    ),
                    Container(
                      child: TextButton(
                        child: const Text(
                          "Bid log >>",
                          style: TextStyle(color: colors.primary),
                        ),
                        onPressed: () {
                          get.Bidlog("0");
                          Get.toNamed("/BidLogpage");
                        },
                      ),
                    ),
                    // IconButton(
                    //   onPressed: () {
                    //     final get1 =
                    //         Get.put(profileController(context: context));
                    //     get1.getprofile();
                    //
                    //     Get.toNamed("/profile");
                    //   },
                    //   icon: Image.asset(
                    //     paths.Ellipse4,
                    //     scale: 4,
                    //   ),
                    // )
                  ],
                ),
              ),
              Obx(() {
                return Column(
                  children: [
                    Container(
                      width: widths * 0.8,
                      decoration: BoxDecoration(
                          color: colors.primary2,
                          border: Border.all(color: colors.primary),
                          borderRadius: BorderRadius.circular(20)),
                      child: Column(
                        children: [
                          SizedBox(
                            width: widths * 0.75,
                            child: Text(
                              textAlign: TextAlign.center,
                              "Auction Name : ${get.Response3.value.responseData!.auctionBrief}",
                              style: const TextStyle(
                                  color: colors.primary,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                          SizedBox(
                            width: widths * 0.75,
                            child: Text(
                              textAlign: TextAlign.center,
                              "Department Name : ${get.Response3.value.responseData!.departmentName}",
                              style: TextStyle(
                                  color: colors.primary,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ),
                    ),
                    sbh(5.0),
                    Container(
                      width: widths * 0.8,
                      child: Row(
                        children: [
                          Container(
                            width: widths * 0.5,
                            child: Column(
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      width: 70,
                                      child: const Text(
                                        "Start Date",
                                        style: TextStyle(fontSize: 10),
                                      ),
                                    ),
                                    const Text(
                                      ":  ",
                                      style: TextStyle(fontSize: 10),
                                    ),
                                    Text(
                                      get.Response11.value.responseData!
                                          .biddingHallDetail![0].startdate
                                          .toString(),
                                      style: const TextStyle(fontSize: 10),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    const SizedBox(
                                      width: 70,
                                      child: Text(
                                        "Current Date",
                                        style: TextStyle(fontSize: 10),
                                      ),
                                    ),
                                    const Text(
                                      ":  ",
                                      style: TextStyle(fontSize: 10),
                                    ),
                                    Text(
                                      get.Response11.value.responseData!
                                          .biddingHallDetail![0].enddate
                                          .toString(),
                                      style: TextStyle(fontSize: 10),
                                    ),
                                  ],
                                )
                              ],
                            ),
                          ),
                          const Expanded(child: Text("")),
                          Container(
                            width: widths * 0.25,
                            height: 30,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                                color: colors.primary,
                                borderRadius: BorderRadius.circular(20)),
                            child: Text(
                              "${Remaining(get.Response11.value.responseData!.biddingHallDetail![0].enddatevirtual.toString())} Days left",
                              style: const TextStyle(color: Colors.white),
                            ),
                          )
                        ],
                      ),
                    ),
                    SingleChildScrollView(
                      child: SizedBox(
                        height: heights * 0.75,
                        child: ListView.builder(
                          scrollDirection: Axis.vertical,
                          itemCount: get.Response11.value.responseData
                              ?.biddingHallDetail?.length,
                          itemBuilder: (context, index) {
                            _controllers.add(TextEditingController());
                            return ListItem(
                              index: index,
                              controller: _controllers[index],
                            );
                          },
                        ),
                      ),
                    ),
                  ],
                );
              })
            ],
          ),
        ),
      ),
    );
  }
}

class ListItem extends StatefulWidget {
  final TextEditingController controller;
  final int index;

  ListItem({required this.index, required this.controller});

  @override
  _ListItemState createState() => _ListItemState();
}

class _ListItemState extends State<ListItem> {
  //bool _isSelected = false;
  String TotalRate = "";
  String Nextpossible = "";
  int itemnameindex = -1;
  int qunindex = -1;
  int yourrankindex = -1;
  int nextpossindex = -1;
  int lastbidindex = -1;
  int startindex = -1;
  int incrementindex = -1;
  int h1bidindex = -1;
  int totalrateindex = -1;
  var autobiddingstates = false;
  var value = TextEditingController();
  final _lock = Lock();

  Future<void> autobidding() async {
    print("autobidding on");

    final get = Get.put(homeController(context: context));
    // Calculate indices once
    final auctionColumnHeader =
        get.Response11.value.responseData!.auctionColumnHeader!;
    qunindex =
        auctionColumnHeader.indexWhere((element) => element.columntypeid == 2);
    yourrankindex = auctionColumnHeader
        .indexWhere((element) => element.columntypeid == 10005);
    nextpossindex = auctionColumnHeader
        .indexWhere((element) => element.columntypeid == 10003);
    startindex = auctionColumnHeader
        .indexWhere((element) => element.columntypeid == 10001);
    incrementindex = auctionColumnHeader
        .indexWhere((element) => element.columntypeid == 10007);
    h1bidindex = auctionColumnHeader
        .indexWhere((element) => element.columntypeid == 10002);
    totalrateindex =
        auctionColumnHeader.indexWhere((element) => element.columntypeid == 5);

    // Fetch the necessary details once
    final biddingHallDetail =
        get.Response11.value.responseData!.biddingHallDetail![widget.index];
    final auctionCellValueList = biddingHallDetail.auctionCellValueList!;
    final detail =
        get.Response11.value.responseData!.biddingHallDetail![widget.index];

    // Fetching required cell values once
    String table = auctionCellValueList[widget.index].tableid.toString();
    String row = auctionCellValueList[widget.index].rowid.toString();
    String trci = auctionCellValueList[totalrateindex].cellid.toString();
    String totalRatecellValue =
        auctionCellValueList[totalrateindex].cellvalue.toString();
    DateTime endDate = DateFormat("dd/MM/yyyy HH:mm:ss")
        .parse(biddingHallDetail.enddate.toString());

    // Parsing required cell values
    double cellValue1 =
        double.parse(auctionCellValueList[qunindex].cellvalue.toString());
    double cellValue5 =
        double.parse(auctionCellValueList[h1bidindex].cellvalue.toString());
    double cellValue7 =
        double.parse(auctionCellValueList[incrementindex].cellvalue.toString());
    double cellValue3 =
        double.parse(auctionCellValueList[startindex].cellvalue.toString());

    // Get the current date without time
    DateTime currentDate = DateTime.now();
    currentDate =
        DateTime(currentDate.year, currentDate.month, currentDate.day);

    // Calculate the difference in days
    Duration difference = endDate.difference(currentDate);

    bool nextFilledBy =
        auctionColumnHeader[nextpossindex].filledby.toString() == "1";
    bool firstBidCond = detail.firstbidcond.toString() == "1";
    bool eventTypeIsOne = detail.eventtypeid.toString() == "1";

    String Next = nextFilledBy
        ? auctionCellValueList[nextpossindex].cellvalue.toString()
        : eventTypeIsOne
            ? cellValue5 > 0.00
                ? (cellValue5 + cellValue7).toString()
                : firstBidCond
                    ? cellValue3.toString()
                    : (cellValue3 + cellValue7).toString()
            : cellValue5 > 0.00
                ? (cellValue5 - cellValue7).toString()
                : firstBidCond
                    ? cellValue3.toString()
                    : (cellValue3 - cellValue7).toString();

    String Total = nextFilledBy
        ? auctionCellValueList[nextpossindex].cellvalue.toString()
        : eventTypeIsOne
            ? cellValue5 > 0.00
                ? ((cellValue5 + cellValue7) * cellValue1).toString()
                : firstBidCond
                    ? (cellValue3 * cellValue1).toString()
                    : ((cellValue3 + cellValue7) * cellValue1).toString()
            : cellValue5 > 0.00
                ? ((cellValue5 - cellValue7) * cellValue1).toString()
                : firstBidCond
                    ? (cellValue3 * cellValue1).toString()
                    : ((cellValue3 - cellValue7) * cellValue1).toString();

    print("next" + Next);
    print("total" + Total);

    final FlutterTts flutterTts = FlutterTts();
    await flutterTts.setLanguage("en-US");
    await flutterTts.setPitch(1.0);

    if (difference != Duration.zero) {
      print("difference  " + difference.toString());

      if (auctionCellValueList[yourrankindex].cellvalue.toString() != "1") {
        double nextValue = double.parse(Next);
        double inputValue = double.parse(widget.controller.text);

        if (eventTypeIsOne ? inputValue > nextValue : inputValue < nextValue) {
          print("bidsubmit");
          await get.Bidsubmit(
              table, row, Next, Total, trci, totalRatecellValue);
        } else {
          autobiddingstates = false;
          countdownTimer?.cancel();
          await flutterTts.speak(eventTypeIsOne
              ? "increase your limit value"
              : "decrease your limit value");
        }
      } else {
        print("your rank is 1");
      }
    }

    print("autobidding com");
  }

  // Future<void> autobidding() async {
  //   print("autobidding on");
  //
  //   final get = Get.put(homeController(context: context));
  //   // Calculate indices once
  //   final auctionColumnHeader =
  //       get.Response11.value.responseData!.auctionColumnHeader!;
  //   qunindex =
  //       auctionColumnHeader.indexWhere((element) => element.columntypeid == 2);
  //   yourrankindex = auctionColumnHeader
  //       .indexWhere((element) => element.columntypeid == 10005);
  //   nextpossindex = auctionColumnHeader
  //       .indexWhere((element) => element.columntypeid == 10003);
  //   startindex = auctionColumnHeader
  //       .indexWhere((element) => element.columntypeid == 10001);
  //   incrementindex = auctionColumnHeader
  //       .indexWhere((element) => element.columntypeid == 10007);
  //   h1bidindex = auctionColumnHeader
  //       .indexWhere((element) => element.columntypeid == 10002);
  //   totalrateindex =
  //       auctionColumnHeader.indexWhere((element) => element.columntypeid == 5);
  //
  //   // Fetch the necessary details once
  //   final biddingHallDetail =
  //       get.Response11.value.responseData!.biddingHallDetail![widget.index];
  //   final auctionCellValueList = biddingHallDetail.auctionCellValueList!;
  //   final detail =
  //       get.Response11.value.responseData!.biddingHallDetail![widget.index];
  //
  //   // Fetching required cell values once
  //   String table = auctionCellValueList[widget.index].tableid.toString();
  //   String row = auctionCellValueList[widget.index].rowid.toString();
  //   String trci = auctionCellValueList[totalrateindex].cellid.toString();
  //   String totalRatecellValue =
  //       auctionCellValueList[totalrateindex].cellvalue.toString();
  //   DateTime endDate = DateFormat("dd/MM/yyyy HH:mm:ss")
  //       .parse(biddingHallDetail.enddate.toString());
  //
  //   // Parsing required cell values
  //   double cellValue1 =
  //       double.parse(auctionCellValueList[qunindex].cellvalue.toString());
  //   double cellValue5 =
  //       double.parse(auctionCellValueList[h1bidindex].cellvalue.toString());
  //   double cellValue7 =
  //       double.parse(auctionCellValueList[incrementindex].cellvalue.toString());
  //   double cellValue3 =
  //       double.parse(auctionCellValueList[startindex].cellvalue.toString());
  //
  //   // Get the current date without time
  //   DateTime currentDate = DateTime.now();
  //   currentDate =
  //       DateTime(currentDate.year, currentDate.month, currentDate.day);
  //
  //   // Calculate the difference in days
  //   Duration difference = endDate.difference(currentDate);
  //
  //   bool nextFilledBy =
  //       auctionColumnHeader[nextpossindex].filledby.toString() == "1";
  //   bool firstBidCond = detail.firstbidcond.toString() == "1";
  //   bool eventTypeIsOne = detail.eventtypeid.toString() == "1";
  //
  //   String Next = nextFilledBy
  //       ? auctionCellValueList[nextpossindex].cellvalue.toString()
  //       : eventTypeIsOne
  //           ? cellValue5 > 0.00
  //               ? (cellValue5 + cellValue7).toString()
  //               : firstBidCond
  //                   ? cellValue3.toString()
  //                   : (cellValue3 + cellValue7).toString()
  //           : cellValue5 > 0.00
  //               ? (cellValue5 - cellValue7).toString()
  //               : firstBidCond
  //                   ? cellValue3.toString()
  //                   : (cellValue3 - cellValue7).toString();
  //
  //   String Total = nextFilledBy
  //       ? auctionCellValueList[nextpossindex].cellvalue.toString()
  //       : eventTypeIsOne
  //           ? cellValue5 > 0.00
  //               ? ((cellValue5 + cellValue7) * cellValue1).toString()
  //               : firstBidCond
  //                   ? (cellValue3 * cellValue1).toString()
  //                   : ((cellValue3 + cellValue7) * cellValue1).toString()
  //           : cellValue5 > 0.00
  //               ? ((cellValue5 - cellValue7) * cellValue1).toString()
  //               : firstBidCond
  //                   ? (cellValue3 * cellValue1).toString()
  //                   : ((cellValue3 - cellValue7) * cellValue1).toString();
  //
  //   print("next" + Next);
  //   print("total" + Total);
  //
  //   final FlutterTts flutterTts = FlutterTts();
  //   await flutterTts.setLanguage("en-US");
  //   await flutterTts.setPitch(1.0);
  //
  //   if (difference != Duration.zero) {
  //     print("difference  " + difference.toString());
  //
  //     if (auctionCellValueList[yourrankindex].cellvalue.toString() != "1") {
  //       double nextValue = double.parse(Next);
  //       double inputValue = double.parse(widget.controller.text);
  //
  //       if (eventTypeIsOne ? inputValue > nextValue : inputValue < nextValue) {
  //         print("bidsubmit");
  //         await get.Bidsubmit(
  //             table, row, Next, Total, trci, totalRatecellValue);
  //       } else {
  //         autobiddingstates = false;
  //         countdownTimer?.cancel();
  //         await flutterTts.speak(eventTypeIsOne
  //             ? "increase your limit value"
  //             : "decrease your limit value");
  //       }
  //     } else {
  //       print("your rank is 1");
  //     }
  //   }
  //
  //   print("autobidding com");
  // }

  String indexf() {
    final get = Get.put(homeController(context: context));
    //final detail = get.Response11.value.responseData!.biddingHallDetail![0];
    //final cellValueList = detail.auctionCellValueList!;
    itemnameindex = get.Response11.value.responseData!.auctionColumnHeader!
        .indexWhere((element) => element.columntypeid == 1);
    qunindex = get.Response11.value.responseData!.auctionColumnHeader!
        .indexWhere((element) => element.columntypeid == 2);
    yourrankindex = get.Response11.value.responseData!.auctionColumnHeader!
        .indexWhere((element) => element.columntypeid == 10005);
    nextpossindex = get.Response11.value.responseData!.auctionColumnHeader!
        .indexWhere((element) => element.columntypeid == 10003);
    lastbidindex = get.Response11.value.responseData!.auctionColumnHeader!
        .indexWhere((element) => element.columntypeid == 10004);
    startindex = get.Response11.value.responseData!.auctionColumnHeader!
        .indexWhere((element) => element.columntypeid == 10001);
    incrementindex = get.Response11.value.responseData!.auctionColumnHeader!
        .indexWhere((element) => element.columntypeid == 10007);
    h1bidindex = get.Response11.value.responseData!.auctionColumnHeader!
        .indexWhere((element) => element.columntypeid == 10002);
    totalrateindex = get.Response11.value.responseData!.auctionColumnHeader!
        .indexWhere((element) => element.columntypeid == 5);
    return "null";
  }

  var remainingSeconds = 30.obs;
  Timer? countdownTimer;
  void _startCountdownTimer() {
    countdownTimer?.cancel(); // Cancel any existing timer
    remainingSeconds.value = 30;
    //final get = Get.put(homeController(context: context));
    countdownTimer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (remainingSeconds.value > 0) {
        setState(() {
          remainingSeconds.value--;
        });

        if (autobiddingstates == false) {
          timer.cancel();
        }
        setState(() {});
      } else {
        timer.cancel();
        performTask(); // Perform the task again after countdown finishes
      }
    });
  }

  Future<void> performTask() async {
    final get = Get.put(homeController(context: context));
    if (autobiddingstates && get.autobiddingstates) {
      await _lock.synchronized(() async {
        await get.Dynbiddinghallauto("auto");
        await autobidding();
        await get.Dynbiddinghallauto("auto");
      });
      // await Future.delayed(Duration(seconds: 7));
      _startCountdownTimer();
    } else {
      autobiddingstates = false;
    }
    // Perform the task here (simulate with a delay)

    // Task completed, start the countdown timer
  }

  @override
  void initState() {
    // TODO: implement initState
    //final get = Get.put(homeController(context: context));
    //final get1 = Get.put(TimerController(context: context));
    autobiddingstates = widget.controller.text == "" ? false : true;
    indexf();
    if (autobiddingstates == true) {
      performTask();
    }
    if (autobiddingstates == false) {
      countdownTimer?.cancel();
    }
    super.initState();
  }

  @override
  void dispose() {
    value.clear();
    autobiddingstates = false;
    // TODO: implement dispose
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // final heights = MediaQuery.of(context).size.height;
    final widths = MediaQuery.of(context).size.width;
    final get = Get.put(homeController(context: context));

    //final get1 = Get.put(TimerController(context: context));
    final detail = get.Response11.value.responseData!.biddingHallDetail![0];
    final cellValueList = detail.auctionCellValueList!;
    //double cellValue1 =
    double.parse(cellValueList[qunindex].cellvalue.toString());

    //double cellValue5 =
    double.parse(cellValueList[h1bidindex].cellvalue.toString()); //h1

    //double cellValue7 =
    double.parse(cellValueList[incrementindex].cellvalue.toString()); //inc
    //double cellValue3 =
    double.parse(cellValueList[startindex].cellvalue.toString()); //start
    Future<bool?> showBackDialog() {
      return showDialog<bool>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text(
              'Are you sure?',
              style: TextStyle(color: colors.primary),
            ),
            content: const Text(
              'Are you sure you want to off auto bid ?',
            ),
            actions: <Widget>[
              TextButton(
                style: TextButton.styleFrom(
                  textStyle: Theme.of(context).textTheme.labelLarge,
                ),
                child: const Text('cancel',
                    style: TextStyle(color: colors.primary)),
                onPressed: () {
                  Navigator.pop(context, false);
                },
              ),
              TextButton(
                style: TextButton.styleFrom(
                  textStyle: Theme.of(context).textTheme.labelLarge,
                ),
                child:
                    const Text('Off', style: TextStyle(color: colors.primary)),
                onPressed: () {
                  // get.GetitemSelection(
                  //     get.Response3.value.responseData!.auctionId.toString());
                  Get.toNamed("/itemselection");
                },
              ),
            ],
          );
        },
      );
    }

    return PopScope(
      canPop: false,
      onPopInvoked: (bool didPop) async {
        if (didPop) {
          return;
        }
        final bool shouldPop =
            get.autobiddingstates ? await showBackDialog() ?? false : false;
        if (context.mounted && shouldPop) {
          get.GetitemSelection(
              get.Response3.value.responseData!.auctionId.toString());
          Get.toNamed("/itemselection");
        } else {}
      },
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: widths * 0.9,
            child: Table(
              // border: TableBorder(
              //   horizontalInside: BorderSide(color: Colors.grey, width: 1),
              //   verticalInside: BorderSide(color: Colors.grey, width: 1),
              // ),
              columnWidths: const <int, TableColumnWidth>{
                0: IntrinsicColumnWidth(),
                1: FlexColumnWidth(),
              },
              children: [
                TableRow(
                  children: [
                    Container(
                      child: Row(
                        children: [
                          const Text(
                            "Item name : ",
                            style: TextStyle(
                                color: colors.primary,
                                fontWeight: FontWeight.bold),
                          ),
                          sbh(5.0),
                          Text(get
                              .Response11
                              .value
                              .responseData!
                              .biddingHallDetail![widget.index]
                              .auctionCellValueList![itemnameindex]
                              .cellvalue
                              .toString()),
                        ],
                      ),
                    ),
                    Container(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          sbh(10.0),
                          const Text(
                            "H1 Bid : ",
                            style: TextStyle(
                                color: colors.primary,
                                fontWeight: FontWeight.bold),
                          ),
                          sbh(5.0),
                          Container(
                            width: widths * 0.28,
                            child: Text(get
                                .Response11
                                .value
                                .responseData!
                                .biddingHallDetail![widget.index]
                                .auctionCellValueList![h1bidindex]
                                .cellvalue
                                .toString()),
                          ),
                          sbh(10.0),
                        ],
                      ),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    Container(
                      width: widths * 0.35,
                      child: Row(
                        children: [
                          sbh(10.0),
                          const Text(
                            "Your Rank : ",
                            style: TextStyle(
                                color: colors.primary,
                                fontWeight: FontWeight.bold),
                          ),
                          sbh(5.0),
                          Text(get
                              .Response11
                              .value
                              .responseData!
                              .biddingHallDetail![widget.index]
                              .auctionCellValueList![yourrankindex]
                              .cellvalue
                              .toString()),
                          sbh(10.0),
                        ],
                      ),
                    ),
                    Container(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          sbh(15.0),
                          const Text(
                            "Last bid price : ",
                            style: TextStyle(
                                color: colors.primary,
                                fontWeight: FontWeight.bold),
                          ),
                          SizedBox(
                            width: widths * 0.28,
                            child: Text(get
                                .Response11
                                .value
                                .responseData!
                                .biddingHallDetail![widget.index]
                                .auctionCellValueList![lastbidindex]
                                .cellvalue
                                .toString()),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Next Bid in ",
                          style: TextStyle(
                              color: colors.primary,
                              fontWeight: FontWeight.bold),
                        ),
                        Container(
                          child: Text(
                              textAlign: TextAlign.center,
                              style: TextStyle(fontWeight: FontWeight.bold),
                              "${remainingSeconds.value.toString()} S."),
                        ),
                      ],
                    ),
                    const Text(
                      "Enter your limit : ",
                      style: TextStyle(
                          color: colors.primary, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Auto Bid : ",
                          style: TextStyle(
                              color: colors.primary,
                              fontWeight: FontWeight.bold),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            SizedBox(
                              height: 40,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Text("OFF "),
                                  Switch(
                                    // This bool value toggles the switch.
                                    value: autobiddingstates,
                                    activeColor: colors.primary,
                                    onChanged: (bool value) {
                                      setState(() {
                                        autobiddingstates = value;
                                        print(
                                            "enter " + widget.controller.text);
                                        if (value == true) {
                                          performTask();
                                        }
                                        if (autobiddingstates == false) {
                                          countdownTimer?.cancel();
                                        }
                                        if (widget.controller.text == "") {
                                          autobiddingstates = false;
                                        }
                                      });
                                      if (autobiddingstates == false) {
                                        countdownTimer?.cancel();
                                      }
                                    },
                                  ),
                                  const Text(" ON"),
                                ],
                              ),
                            ),
                            sbh(10.0),
                          ],
                        ),
                      ],
                    ),
                    SizedBox(
                      width: widths * 0.5,
                      child: Column(
                        children: [
                          sbh(10.0),
                          SizedBox(
                            height: 40,
                            child: TextField(
                              // onChanged: (a) {
                              //   TotalRateValue(a);
                              // },
                              // onTap: () {
                              //   // _controllers.text = Nextpossible;
                              // },
                              onSubmitted: (value) {
                                autobiddingstates = true;
                                performTask();
                              },
                              maxLines: 1,
                              style: TextStyle(fontSize: 15),
                              textAlignVertical: TextAlignVertical.center,
                              textAlign: TextAlign.start,

                              cursorColor: colors.primary,
                              decoration: InputDecoration(
                                  contentPadding: const EdgeInsets.symmetric(
                                      vertical: 5.0, horizontal: 10),
                                  focusedBorder: const OutlineInputBorder(
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(8)),
                                    borderSide:
                                        BorderSide(color: colors.primary),
                                  ),
                                  enabledBorder: const OutlineInputBorder(
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(8)),
                                    borderSide:
                                        BorderSide(color: colors.primary),
                                  ),
                                  hintText: widget.controller.text == ""
                                      ? "enter value"
                                      : widget.controller.text),
                              controller: widget.controller,
                              keyboardType: TextInputType.number,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const Divider()
        ],
      ),
    );
  }
}

// TableRow(
//   children: [
//     Container(
//       child: Column(
//         children: [
//           SizedBox(
//             height: 15,
//           ),
//           Text(
//             "Next possible bid",
//             style: TextStyle(
//                 color: colors.primary,
//                 fontWeight: FontWeight.bold),
//           ),
//           SizedBox(
//             height: 5,
//           ),
//           Text(get
//                       .Response11
//                       .value
//                       .responseData!
//                       .auctionColumnHeader![
//                           nextpossindex]
//                       .filledby
//                       .toString() ==
//                   "1"
//               ? get
//                   .Response11
//                   .value
//                   .responseData!
//                   .biddingHallDetail![0]
//                   .auctionCellValueList![
//                       nextpossindex]
//                   .cellvalue
//                   .toString()
//               : get
//                           .Response11
//                           .value
//                           .responseData!
//                           .biddingHallDetail![0]
//                           .eventtypeid
//                           .toString() ==
//                       "1"
//                   ? cellValue5 > 0.00
//                       ? (cellValue5 + cellValue7)
//                           .toString()
//                       : detail.firstbidcond
//                                   .toString() ==
//                               "1"
//                           ? cellValue3.toString()
//                           : (cellValue3 + cellValue7)
//                               .toString()
//                   : cellValue5 > 0.00
//                       ? (cellValue5 - cellValue7)
//                           .toString()
//                       : detail.firstbidcond
//                                   .toString() ==
//                               "1"
//                           ? cellValue3.toString()
//                           : (cellValue3 - cellValue7)
//                               .toString()),
//           SizedBox(
//             height: 10,
//           )
//         ],
//       ),
//     ),
//     Container(
//       child: Column(
//         children: [
//           SizedBox(
//             height: 15,
//           ),
//           Text(
//             "Total Rate",
//             style: TextStyle(
//                 color: colors.primary,
//                 fontWeight: FontWeight.bold),
//           ),
//           SizedBox(
//             height: 5,
//           ),
//           Text(
//             get
//                         .Response11
//                         .value
//                         .responseData!
//                         .auctionColumnHeader![
//                             nextpossindex]
//                         .filledby
//                         .toString() ==
//                     "1"
//                 ? get
//                     .Response11
//                     .value
//                     .responseData!
//                     .biddingHallDetail![0]
//                     .auctionCellValueList![
//                         nextpossindex]
//                     .cellvalue
//                     .toString()
//                 : get
//                             .Response11
//                             .value
//                             .responseData!
//                             .biddingHallDetail![0]
//                             .eventtypeid
//                             .toString() ==
//                         "1"
//                     ? cellValue5 > 0.00
//                         ? ((cellValue5 + cellValue7) * cellValue1)
//                             .toString()
//                         : detail.firstbidcond.toString() ==
//                                 "1"
//                             ? (cellValue3 * cellValue1)
//                                 .toString()
//                             : ((cellValue3 + cellValue7) * cellValue1)
//                                 .toString()
//                     : cellValue5 > 0.00
//                         ? ((cellValue5 - cellValue7) *
//                                 cellValue1)
//                             .toString()
//                         : detail.firstbidcond.toString() ==
//                                 "1"
//                             ? (cellValue3 * cellValue1)
//                                 .toString()
//                             : ((cellValue3 - cellValue7) *
//                                     cellValue1)
//                                 .toString(),
//           ),
//           SizedBox(
//             height: 10,
//           )
//         ],
//       ),
//     ),
//   ],
// ),
// Row(
//   children: [
//     Container(
//       child: Text("enter your limit"),
//     ),
//     Container(
//       width: widths * 0.5,
//       height: 40,
//       child: TextField(
//         // onChanged: (a) {
//         //   TotalRateValue(a);
//         // },
//         // onTap: () {
//         //   // _controllers.text = Nextpossible;
//         // },
//
//         textAlign: TextAlign.start,
//         textAlignVertical: TextAlignVertical.top,
//         cursorColor: colors.primary,
//         decoration: InputDecoration(
//             focusedBorder: OutlineInputBorder(
//               borderRadius: BorderRadius.all(Radius.circular(8)),
//               borderSide: BorderSide(color: colors.primary),
//             ),
//             enabledBorder: OutlineInputBorder(
//               borderRadius: BorderRadius.all(Radius.circular(8)),
//               borderSide: BorderSide(color: colors.primary),
//             ),
//             hintText: widget.controller.text == ""
//                 ? "enter value"
//                 : widget.controller.text),
//         controller: widget.controller,
//         keyboardType: TextInputType.number,
//       ),
//     ),
//   ],
// ),

// Container(
//   width: widths,
//   child: Column(
//     mainAxisAlignment: MainAxisAlignment.center,
//     children: [
//       Text(
//         "Auto Bidding States",
//         style: TextStyle(
//             color: colors.primary, fontWeight: FontWeight.bold),
//       ),
//       SizedBox(
//         height: 5,
//       ),
//       Row(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           Text("OFF   "),
//           Switch(
//             // This bool value toggles the switch.
//             value: get.autobiddingstates,
//             activeColor: colors.primary,
//             onChanged: (bool value) {
//               setState(() {
//                 get.autobiddingstates = value;
//                 if (value == true) {
//                   get1.performTask();
//                 }
//                 if (get.autobiddingstates == false) {
//                   get1.countdownTimer?.cancel();
//                 }
//               });
//               if (get.autobiddingstates == false) {
//                 get1.countdownTimer?.cancel();
//               }
//             },
//           ),
//           Text("   ON"),
//         ],
//       ),
//       SizedBox(
//         height: 10,
//       )
//     ],
//   ),
// ),
// SizedBox(
//   height: 10,
// ),
// Container(
//   padding: EdgeInsets.all(20),
//   width: widths * 0.8,
//   decoration: BoxDecoration(
//       borderRadius: BorderRadius.circular(20),
//       color: Colors.white,
//       boxShadow: [
//         new BoxShadow(
//           offset: Offset(3, 3),
//           blurRadius: 30,
//           spreadRadius: 30,
//           color: Color.fromRGBO(80, 85, 141, 0.14901960784313725),
//         )
//       ]),
//   child: Column(
//     children: [
//       Text(
//         "Your Next Bid in",
//         style: TextStyle(
//             color: colors.primary,
//             fontSize: 18,
//             fontWeight: FontWeight.bold),
//       ),
//       Container(
//         width: widths * 0.7,
//         child: Text(
//             textAlign: TextAlign.center,
//             style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
//             "${get1.remainingSeconds.value.toString()} seconds..."),
//       ),
//       // Lottie.asset(
//       //   paths.gif1,
//       // ),
//       // Container(
//       //   width: widths * 0.7,
//       //   child: Text(
//       //       textAlign: TextAlign.center,
//       //       style: TextStyle(fontSize: 12),
//       //       "From your bidding value, your current rank is lower than "
//       //       "desired. To improve your visibility and increase your chances "
//       //       "of success, we are increasing your bidding value"),
//       // ),
//     ],
//   ),
// ),
// SizedBox(
//   height: 30,
// ),
// Container(
//   width: widths * 0.8,
//   child: Row(
//     mainAxisAlignment: MainAxisAlignment.center,
//     children: [
//       Text(
//         "Your limit value : ",
//         style: TextStyle(
//             color: colors.primary,
//             fontSize: 16,
//             fontWeight: FontWeight.bold),
//       ),
//       Text(get.value.text)
//     ],
//   ),
// ),
// SizedBox(
//   height: 10,
// ),
// Container(
//   width: widths * 0.4,
//   height: 50,
//   decoration: BoxDecoration(
//       border: Border.all(color: colors.primary),
//       borderRadius: BorderRadius.circular(25)),
//   child: TextButton(
//       onPressed: () {
//         Get.toNamed("/autobidding");
//         get.autobiddingstates = false;
//       },
//       child: Text(
//         "Change Auto value",
//         style: TextStyle(color: colors.primary),
//       )),
// ),
// SizedBox(
//   height: 20,
// ),
// String NextpossibleValue() {
//   final get = Get.put(homeController(context: context));
//   final detail = get.Response11.value.responseData!.biddingHallDetail![0];
//   final cellValueList = detail.auctionCellValueList!;
//   double cellValue1 =
//       double.parse(cellValueList[qunindex].cellvalue.toString());
//   double next = double.parse(cellValueList[startindex].cellvalue.toString());
//   double cellValue5 =
//       double.parse(cellValueList[h1bidindex].cellvalue.toString()); //h1
//   double cellValue2 = double.parse(
//       cellValueList[lastbidindex].cellvalue.toString()); //last bid
//   double cellValue7 =
//       double.parse(cellValueList[incrementindex].cellvalue.toString()); //inc
//   double cellValue3 =
//       double.parse(cellValueList[startindex].cellvalue.toString()); //start
//   double filledby =
//       double.parse(cellValueList[startindex].cellvalue.toString());
//
//   if (cellValue5 > 0.00) {
//     Nextpossible = (cellValue5 + cellValue7).toString();
//     TotalRate = ((cellValue5 + cellValue7) * cellValue1).toString();
//
//     return (cellValue5 + cellValue7).toString();
//   } else {
//     if (detail.firstbidcond.toString() == "1") {
//       Nextpossible = cellValue3.toString();
//       TotalRate = (cellValue3 * cellValue1).toString();
//
//       return cellValue3.toString();
//     } else {
//       Nextpossible = (cellValue3 + cellValue7).toString();
//       TotalRate = ((cellValue3 + cellValue7) * cellValue1).toString();
//
//       return (cellValue3 + cellValue7).toString();
//     }
//   }
// }
//
// String Nextpossibledecrement() {
//   final get = Get.put(homeController(context: context));
//   final detail = get.Response11.value.responseData!.biddingHallDetail![0];
//   final cellValueList = detail.auctionCellValueList!;
//   double cellValue1 =
//       double.parse(cellValueList[qunindex].cellvalue.toString());
//   double next = double.parse(cellValueList[startindex].cellvalue.toString());
//   double cellValue5 =
//       double.parse(cellValueList[h1bidindex].cellvalue.toString()); //h1
//   double cellValue2 = double.parse(
//       cellValueList[lastbidindex].cellvalue.toString()); //last bid
//   double cellValue7 =
//       double.parse(cellValueList[incrementindex].cellvalue.toString()); //inc
//   double cellValue3 =
//       double.parse(cellValueList[startindex].cellvalue.toString()); //start
//   double filledby =
//       double.parse(cellValueList[startindex].cellvalue.toString());
//
//   if (cellValue5 > 0.00) {
//     Nextpossible = (cellValue5 - cellValue7).toString();
//     TotalRate = ((cellValue5 - cellValue7) * cellValue1).toString();
//
//     return Nextpossible;
//   } else {
//     if (detail.firstbidcond.toString() == "1") {
//       Nextpossible = cellValue3.toString();
//       TotalRate = (cellValue3 * cellValue1).toString();
//
//       return Nextpossible;
//     } else {
//       Nextpossible = (cellValue3 - cellValue7).toString();
//       TotalRate = ((cellValue3 - cellValue7) * cellValue1).toString();
//
//       return Nextpossible;
//     }
//   }
// }
//
// String TotalRateValue(a) {
//   double next = double.parse(Nextpossible.toString());
//
//   double con = double.parse(a);
//   TotalRate = (next * con).toString();
//   return (next * con).toString();
// }
// Future<void> showDialogforTextField(int item) {
//   return showDialog<bool>(
//     context: context,
//     builder: (BuildContext context) {
//       final get = Get.put(homeController(context: context));
//       itemnameindex = get.Response11.value.responseData!.auctionColumnHeader!
//           .indexWhere((element) => element.columntypeid == 1);
//       return AlertDialog(
//         title: const Text(
//           'enter your limit',
//           style: TextStyle(color: colors.primary),
//         ),
//         content: SingleChildScrollView(
//           child: Container(
//             height: 600,
//             child: ListView.builder(
//                 itemCount: 4,
//                 itemBuilder: (context, index) {
//                   return Container(
//                     child: Row(
//                       children: [
//                         Container(
//                           child: Text(get
//                               .Response11
//                               .value
//                               .responseData!
//                               .biddingHallDetail![index]
//                               .auctionCellValueList![itemnameindex]
//                               .cellvalue
//                               .toString()),
//                         ),
//                         Container(
//                           height: 40,
//                           child: TextField(
//
//                             textAlign: TextAlign.start,
//                             textAlignVertical: TextAlignVertical.top,
//                             cursorColor: colors.primary,
//                             decoration: InputDecoration(
//                                 focusedBorder: OutlineInputBorder(
//                                   borderRadius:
//                                       BorderRadius.all(Radius.circular(8)),
//                                   borderSide:
//                                       BorderSide(color: colors.primary),
//                                 ),
//                                 enabledBorder: OutlineInputBorder(
//                                   borderRadius:
//                                       BorderRadius.all(Radius.circular(8)),
//                                   borderSide:
//                                       BorderSide(color: colors.primary),
//                                 ),
//                                 hintText: "enter value"),
//                             controller: _controllers[index],
//                             keyboardType: TextInputType.number,
//                           ),
//                         ),
//                       ],
//                     ),
//                   );
//                 }),
//           ),
//         ),
//         actions: <Widget>[
//           TextButton(
//             style: TextButton.styleFrom(
//               textStyle: Theme.of(context).textTheme.labelLarge,
//             ),
//             child:
//                 const Text('cancel', style: TextStyle(color: colors.primary)),
//             onPressed: () {
//               Get.back();
//             },
//           ),
//         ],
//       );
//     },
//   );
// }
//final get1 = Get.put(TimerController(context: context));

// Future<bool?> _showBackDialog() {
//   return showDialog<bool>(
//     context: context,
//     builder: (BuildContext context) {
//       return AlertDialog(
//         title: const Text(
//           'Are you sure?',
//           style: TextStyle(color: colors.primary),
//         ),
//         content: const Text(
//           'Are you sure you want to off auto bid ?',
//         ),
//         actions: <Widget>[
//           TextButton(
//             style: TextButton.styleFrom(
//               textStyle: Theme.of(context).textTheme.labelLarge,
//             ),
//             child: const Text('cancel',
//                 style: TextStyle(color: colors.primary)),
//             onPressed: () {
//               Navigator.pop(context, false);
//             },
//           ),
//           TextButton(
//             style: TextButton.styleFrom(
//               textStyle: Theme.of(context).textTheme.labelLarge,
//             ),
//             child:
//                 const Text('Off', style: TextStyle(color: colors.primary)),
//             onPressed: () {
//               get.GetitemSelection(
//                   get.Response3.value.responseData!.auctionId.toString());
//               Get.toNamed("/itemselection");
//             },
//           ),
//         ],
//       );
//     },
//   );
// }
